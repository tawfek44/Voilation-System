package Classes;


import Classes.myexciption;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Basem
 */
public class exciption  extends myexciption{
    public exciption(String message){
        super(message);
    }
}
